/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cuestion2.base;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.*;

/**
 *
 * @author Campus FP
 */
public class Principal {
    public static void main(String[] args) {
        System.out.println("Comienzan las preguntas  \nCada acierto suma 1 punto "
                + "\nEn caso contrario, cada error resta 0.5 puntos");
        ArrayList<String> preguntas_resp = new ArrayList<>();
        ArrayList<Integer> aleatorio = new ArrayList<>();
        
        String ask;
        double puntos=0;
        int pos=0;
        String continuar="1";
       
        
        try {
            Scanner scp = new Scanner(Principal.class.getResourceAsStream("preguntas.txt"));
            Scanner resp = new Scanner(System.in);
            Scanner resp2 = new Scanner(System.in);
            while (scp.hasNext()) {
                String texto = scp.nextLine();
                preguntas_resp.add(texto);
                
                if(pos%2==0){
                    aleatorio.add(pos);
                }
                pos++;
            }
            do {                
                Collections.shuffle(aleatorio);
                ListIterator <Integer> rdnIter = aleatorio.listIterator();
            
                while (rdnIter.hasNext()) {        
                    pos=rdnIter.next();
                    System.out.println(preguntas_resp.get(pos));
                    ask=preguntas_resp.get(pos+1);
                
               
                    if (ask.equalsIgnoreCase(resp.nextLine())){
                        System.out.println("Acierto");
                        puntos++;
                    } else {
                        System.out.println("Fallo");
                        puntos-=0.5;
                    }
                }
                System.out.println("Tus puntos son :"+puntos);
                System.out.println("¿Quieres continuar? (Sí = cualquier tecla || No = 0)");
                continuar=resp2.next();
            } while (!continuar.equalsIgnoreCase("0"));
            System.out.println("Nos vemos amigo");            
        } catch (NullPointerException e ) {
            System.out.println("No se pueden leer las preguntas");
        }
        
        
        
    }//cierra main
}//cierra clas
