/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cuestion1;

/**
 *
 * @author joanc
 */
public class Hija extends Padre{
    //atributos
    int numero;
    
    //Hereda los atributos de la clase Padre
    public Hija(int numero, String nombre, String apellidos) {
        super(nombre, apellidos);
        this.numero=numero;
    }

    @Override
    public String toString() {
        return "Hija{" + "numero=" + numero + " nombre= " + nombre + " apellidos= " + apellidos + '}';
    }

    
    @Override//sobreescritura : método en la clase Hija que sobreescribe la clase Padre 
    public void saludar() {
        System.out.println("Hola, soy la hija");
    }

    //sobrecarga de parámetros
    public void saludar(String nombre) {
        System.out.println("Hola " +nombre +", soy la hija");
    }
    
}
