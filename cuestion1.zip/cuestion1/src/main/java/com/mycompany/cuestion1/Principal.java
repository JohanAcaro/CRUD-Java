/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cuestion1;
        
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

/**
 *
 * @author joanc
 */
public class Principal {
    public static void main(String[] args) {
        //constructor
        System.out.println("HERENCIA\n");
        Padre padre1 = new Padre("Pedro", "Rodríguez");
        padre1.saludar();
        
        Hija hija1 = new Hija(1, "Gema","Rodríguez");
        System.out.println(hija1.toString());
        hija1.saludar();
        hija1.saludar("Eugenia");
        
        //polimorfismo basado en herencia:
        Hija hija2 = new Hija(2, "Jessica", "Rodríguez");
        Padre[] familia= {hija1, padre1};
        familia[1].saludar();
        
        System.out.println("------------------------------------------------------\n");
        System.out.println("COLECCIONES\n");
        System.out.println("LISTA");
        
        ArrayList <String> lista = new ArrayList<>();
        lista.add("Hola");
        lista.add("Adios");
        lista.add("Hasta luego");
        lista.add(3,"Ultimo");
        lista.add(0,"Inicio");
       
        
        ListIterator<String> dataEstructre1 = lista.listIterator();
        while(dataEstructre1.hasNext()){
            System.out.println(dataEstructre1.next());
        }
        
        System.out.println("------------------------------------------------------\n");
        System.out.println("COLA");

        ArrayList<String> elementos = new ArrayList<String>();
        elementos.add("Volvo");
        elementos.add("BMW");
        elementos.add("Ford");
        elementos.add("Mazda");
        elementos.add(0,"Messi");
        
        //cola
        ListIterator<String> dataEstructre2 = elementos.listIterator();
        while(dataEstructre2.hasNext()){
            System.out.println("El coche es "+dataEstructre2.next());
        }
        
        System.out.println("------------------------------------------------------\n");
        System.out.println("PILA");
        //pila
        while(dataEstructre2.hasPrevious()){
            System.out.println("El coche es "+dataEstructre2.previous());
        }
        
        System.out.println("------------------------------------------------------\n");
        System.out.println("TABLA");
        ArrayList<String>[][] arraylist1 = new ArrayList[2][3];
        
        arraylist1[0][0] = new ArrayList<String>();
        arraylist1[0][0].add("1");
        arraylist1[0][0].add("2");
        arraylist1[0][0].add("3");

        arraylist1[0][1] = new ArrayList<String>();
        arraylist1[0][1].add("4");
        arraylist1[0][1].add("5");
        arraylist1[0][1].add("6");

        arraylist1[0][2] = new ArrayList<String >();
        arraylist1[0][2].add("7");
        arraylist1[0][2].add("8");
        arraylist1[0][2].add("9");
        
        arraylist1[1][0] = new ArrayList<String>();
        arraylist1[1][0].add("Mates");
        arraylist1[1][0].add("Lengua");
        arraylist1[1][0].add("Inglés");

        arraylist1[1][1] = new ArrayList<String>();
        arraylist1[1][1].add("Física");
        arraylist1[1][1].add("Química");
        arraylist1[1][1].add("Biología");

        arraylist1[1][2] = new ArrayList<String >();
        arraylist1[1][2].add("Filosofía");
        arraylist1[1][2].add("Historia");
        arraylist1[1][2].add("Economía");      


        System.out.println(Arrays.deepToString(arraylist1[0]));
        System.out.println(Arrays.deepToString(arraylist1[1]));
    }
}
