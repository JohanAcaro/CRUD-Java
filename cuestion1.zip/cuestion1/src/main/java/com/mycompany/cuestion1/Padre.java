/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cuestion1;

/**
 *
 * @author joanc
 */
public class Padre {
    
    //atributos
    String nombre;
    String apellidos;

    //constructor
    public Padre(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
    }
    
    //método
    public void saludar() {
        System.out.println("Hola, soy el padre");
    }
    
}
